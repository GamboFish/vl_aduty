fx_version 'bodacious'
game 'gta5'

author 'rzvmarc - vl scritps'
description 'Aduty System by vl scripts'
version '0.2.0'

lua54 'yes'

shared_script {
	'@es_extended/imports.lua',
	'@es_extended/locale.lua',
	'configs/config.lua'
}

client_scripts {
	'client/*.lua'
}

server_scripts {
	'server/*.lua'
}
dependency '/assetpacks'